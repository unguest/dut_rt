#!/bin/bash

cp -r ./* /srv/http